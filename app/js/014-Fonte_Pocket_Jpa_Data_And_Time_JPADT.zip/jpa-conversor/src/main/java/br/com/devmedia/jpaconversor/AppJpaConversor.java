package br.com.devmedia.jpaconversor;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.devmedia.jpaconversor.entity.User;

public class AppJpaConversor {
    public static void main( String[] args ) {
        System.out.println( "Hello World!" );
        
        User user = new User();
        user.setName("devmedia");
        user.setMyLocalDate(LocalDate.now());
        user.setMyLocalDateTime(LocalDateTime.now());
        
        EntityManagerFactory factory =
        		Persistence.createEntityManagerFactory("JPAUtil");
        
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        em.persist(user);
        em.getTransaction().commit();
        em.close();
        
        em = factory.createEntityManager();
        em.getTransaction().begin();
        User u2 = em.find(User.class, user.getId());
        em.getTransaction().commit();
        em.close();
        factory.close();
        
        System.out.println(u2.toString());
       
    }
}
